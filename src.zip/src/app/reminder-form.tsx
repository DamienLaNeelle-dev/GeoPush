import { Redirect, useLocalSearchParams, useRouter } from "expo-router";
import { useEffect, useRef, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";

import { PlaceList } from "@/components/place-list";
import {
  CATEGORIES,
  CategoryKey,
  MAX_PLACES,
  RADIUS_OPTIONS,
  formatRadius,
} from "@/constants/categories";
import { useAuth } from "@/context/AuthContext";
import { usePlaceSearch } from "@/hooks/use-place-search";
import { useReminders } from "@/hooks/use-reminders";
import { createReminder, updateReminder } from "@/services/reminders/reminderService";
import { Place } from "@/types/place";
import { ReminderInput, ReminderMode } from "@/types/reminder";

function Chip({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected: boolean;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity
      style={[styles.chip, selected && styles.chipSelected]}
      onPress={onPress}
    >
      <Text style={[styles.chipText, selected && styles.chipTextSelected]}>{label}</Text>
    </TouchableOpacity>
  );
}

interface SelectedPlace {
  name: string;
  latitude: number;
  longitude: number;
}

export default function ReminderFormScreen() {
  const router = useRouter();
  const { user } = useAuth();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const { reminders } = useReminders();
  const { places, loading: searching, error: searchError, searched, search, reset } =
    usePlaceSearch();

  const isEdit = !!id;

  const [title, setTitle] = useState("");
  const [mode, setMode] = useState<ReminderMode>("favorite");
  const [categories, setCategories] = useState<CategoryKey[]>([]);
  const [selectedPlace, setSelectedPlace] = useState<SelectedPlace | null>(null);
  const [radius, setRadius] = useState<number>(500);

  // En modification : on pré-remplit le formulaire une seule fois.
  const prefilled = useRef(false);
  useEffect(() => {
    if (!isEdit || prefilled.current) return;
    const existing = reminders.find((r) => r.id === id);
    if (!existing) return;

    setTitle(existing.title);
    setMode(existing.mode);
    setCategories(existing.categories);
    setRadius(existing.radius);

    // Un commerce sans coordonnées (rappel créé à l'étape 2) doit être re-sélectionné.
    if (
      existing.mode === "favorite" &&
      existing.placeName &&
      existing.latitude !== null &&
      existing.longitude !== null
    ) {
      setSelectedPlace({
        name: existing.placeName,
        latitude: existing.latitude,
        longitude: existing.longitude,
      });
    }

    prefilled.current = true;
  }, [isEdit, id, reminders]);

  if (!user) {
    return <Redirect href="/login" />;
  }

  const toggleCategory = (key: CategoryKey) => {
    setCategories((prev) =>
      prev.includes(key) ? prev.filter((k) => k !== key) : [...prev, key]
    );
    reset(); // les anciens résultats ne correspondent plus
  };

  const changeMode = (newMode: ReminderMode) => {
    setMode(newMode);
    setCategories([]);
    setSelectedPlace(null);
    reset();
  };

  const handleSearch = () => {
    if (categories.length === 0) {
      Alert.alert("Erreur", "Choisissez au moins une catégorie de commerce.");
      return;
    }
    search(categories);
  };

  const handleSelectPlace = (place: Place) => {
    setSelectedPlace({
      name: place.name,
      latitude: place.latitude,
      longitude: place.longitude,
    });
    reset();
  };

  const handleSave = () => {
    if (!title.trim()) {
      Alert.alert("Erreur", "Donnez un titre à votre rappel.");
      return;
    }

    let input: ReminderInput;

    if (mode === "favorite") {
      if (!selectedPlace) {
        Alert.alert("Erreur", "Choisissez votre commerce favori dans la liste.");
        return;
      }
      input = {
        title: title.trim(),
        mode,
        placeName: selectedPlace.name,
        latitude: selectedPlace.latitude,
        longitude: selectedPlace.longitude,
        categories: [],
        radius,
      };
    } else {
      if (categories.length === 0) {
        Alert.alert("Erreur", "Choisissez au moins une catégorie de commerce.");
        return;
      }
      input = {
        title: title.trim(),
        mode,
        placeName: null,
        latitude: null,
        longitude: null,
        categories,
        radius,
      };
    }

    // On ne bloque pas l'écran en attendant le serveur : la liste se met à jour
    // tout de suite, et une erreur éventuelle est affichée si elle arrive.
    const request =
      isEdit && id ? updateReminder(user.uid, id, input) : createReminder(user.uid, input);

    request.catch((e) => Alert.alert("Enregistrement impossible", e.message));
    router.back();
  };

  // Bloc "catégories + bouton de recherche + résultats", partagé par les deux modes.
  const renderSearch = (onSelect?: (place: Place) => void) => (
    <>
      <View style={styles.row}>
        {CATEGORIES.map((c) => (
          <Chip
            key={c.key}
            label={c.label}
            selected={categories.includes(c.key)}
            onPress={() => toggleCategory(c.key)}
          />
        ))}
      </View>

      <TouchableOpacity style={styles.secondaryButton} onPress={handleSearch} disabled={searching}>
        {searching ? (
          <ActivityIndicator />
        ) : (
          <Text style={styles.secondaryButtonText}>
            {onSelect ? "Rechercher autour de moi" : "Voir les commerces trouvés"}
          </Text>
        )}
      </TouchableOpacity>

      {searchError && <Text style={styles.error}>{searchError}</Text>}

      {searched && places.length === 0 && (
        <Text style={styles.hint}>Aucun commerce trouvé dans un rayon de 3 km.</Text>
      )}

      {places.length > 0 && (
        <>
          <Text style={styles.hint}>
            {places.length} commerce{places.length > 1 ? "s" : ""} (maximum {MAX_PLACES}, du plus
            proche au plus lointain){onSelect ? " — touchez pour choisir :" : " :"}
          </Text>
          <PlaceList places={places} onSelect={onSelect} />
        </>
      )}
    </>
  );

  return (
    <KeyboardAvoidingView
      style={{ flex: 1, backgroundColor: "#FFFFFF" }}
      behavior={Platform.OS === "ios" ? "padding" : undefined}
    >
      <ScrollView contentContainerStyle={styles.container} keyboardShouldPersistTaps="handled">
        <Text style={styles.screenTitle}>
          {isEdit ? "Modifier le rappel" : "Nouveau rappel"}
        </Text>

        <Text style={styles.label}>Titre</Text>
        <TextInput
          style={styles.input}
          placeholder="Ex : Acheter du pain"
          value={title}
          onChangeText={setTitle}
        />

        <Text style={styles.label}>Mode de localisation</Text>
        <View style={styles.row}>
          <Chip
            label="Commerce favori"
            selected={mode === "favorite"}
            onPress={() => changeMode("favorite")}
          />
          <Chip
            label="Recherche à proximité"
            selected={mode === "nearby"}
            onPress={() => changeMode("nearby")}
          />
        </View>

        {mode === "favorite" ? (
          <>
            <Text style={styles.label}>Mon commerce</Text>

            {selectedPlace ? (
              <View style={styles.selectedCard}>
                <Text style={styles.selectedName}>📍 {selectedPlace.name}</Text>
                <TouchableOpacity onPress={() => setSelectedPlace(null)}>
                  <Text style={styles.change}>Changer</Text>
                </TouchableOpacity>
              </View>
            ) : (
              <>
                <Text style={styles.hint}>
                  Choisissez un type de commerce, puis votre commerce dans la liste.
                </Text>
                {renderSearch(handleSelectPlace)}
              </>
            )}
          </>
        ) : (
          <>
            <Text style={styles.label}>Que recherchez-vous ?</Text>
            <Text style={styles.hint}>
              Ex : pour du pain, cochez Boulangerie et Supermarché. Vous serez prévenu près de
              n'importe lequel (20 commerces maximum).
            </Text>
            {renderSearch()}
          </>
        )}

        <Text style={styles.label}>Rayon de déclenchement</Text>
        <View style={styles.row}>
          {RADIUS_OPTIONS.map((r) => (
            <Chip
              key={r}
              label={formatRadius(r)}
              selected={radius === r}
              onPress={() => setRadius(r)}
            />
          ))}
        </View>

        <TouchableOpacity style={styles.button} onPress={handleSave}>
          <Text style={styles.buttonText}>Enregistrer</Text>
        </TouchableOpacity>

        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.cancel}>Annuler</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  container: { padding: 25, paddingTop: 30, paddingBottom: 60 },
  screenTitle: { fontSize: 26, fontWeight: "bold", marginBottom: 25 },
  label: { fontSize: 14, fontWeight: "600", marginBottom: 8, marginTop: 14 },
  hint: { fontSize: 13, color: "#777777", marginBottom: 10 },
  error: { fontSize: 13, color: "#D64545", marginBottom: 10 },
  input: {
    height: 55,
    borderWidth: 1,
    borderColor: "#DDDDDD",
    borderRadius: 10,
    paddingHorizontal: 15,
    marginBottom: 10,
  },
  row: { flexDirection: "row", flexWrap: "wrap", gap: 8, marginBottom: 10 },
  chip: {
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "#DDDDDD",
  },
  chipSelected: { backgroundColor: "#5B4BDB", borderColor: "#5B4BDB" },
  chipText: { color: "#333333" },
  chipTextSelected: { color: "#FFFFFF", fontWeight: "600" },
  secondaryButton: {
    height: 48,
    borderWidth: 1,
    borderColor: "#5B4BDB",
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 12,
  },
  secondaryButtonText: { color: "#5B4BDB", fontWeight: "600" },
  selectedCard: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    padding: 14,
    borderRadius: 10,
    backgroundColor: "#F2F0FF",
    marginBottom: 10,
  },
  selectedName: { fontSize: 15, fontWeight: "600", flex: 1 },
  change: { color: "#5B4BDB", fontWeight: "600", marginLeft: 10 },
  button: {
    height: 55,
    backgroundColor: "#5B4BDB",
    borderRadius: 10,
    justifyContent: "center",
    alignItems: "center",
    marginTop: 25,
  },
  buttonText: { color: "#FFFFFF", fontSize: 16, fontWeight: "bold" },
  cancel: { color: "#5B4BDB", textAlign: "center", marginTop: 20 },
});
