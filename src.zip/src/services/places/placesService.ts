import AsyncStorage from "@react-native-async-storage/async-storage";

import {
  CATEGORIES,
  CategoryKey,
  MAX_PLACES,
  SEARCH_RADIUS,
} from "../../constants/categories";
import { Place } from "../../types/place";
import { distanceInMeters } from "../../utils/geo";

// Plusieurs serveurs Overpass publics. On les essaie en décalé (un nouveau toutes les
// 2 s tant qu'aucun n'a répondu) et le premier qui répond gagne.
const OVERPASS_ENDPOINTS = [
  "https://overpass-api.de/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
  "https://maps.mail.ru/osm/tools/overpass/api/interpreter",
  "https://overpass.kumi.systems/api/interpreter",
  "https://lz4.overpass-api.de/api/interpreter",
];

const STAGGER_DELAY = 2000; // délai avant de lancer le serveur suivant
const REQUEST_TIMEOUT = 20000; // 20 s max par serveur

const CACHE_TTL = 24 * 60 * 60 * 1000; // 24 h

type PlaceWithoutDistance = Omit<Place, "distance">;

interface OverpassElement {
  type: string;
  id: number;
  lat?: number;
  lon?: number;
  center?: { lat: number; lon: number };
  tags?: Record<string, string>;
}

// --- Requête Overpass -------------------------------------------------------

const buildQuery = (
  lat: number,
  lon: number,
  categories: CategoryKey[],
  radius: number
): string => {
  const parts = categories
    .map((key) => {
      const category = CATEGORIES.find((c) => c.key === key);
      if (!category) return "";
      const [tag, value] = category.osm.split("=");
      return `nwr["${tag}"="${value}"](around:${radius},${lat},${lon});`;
    })
    .join("");

  return `[out:json][timeout:15];(${parts});out center tags;`;
};

type OverpassResult = { elements: OverpassElement[] };

const hostOf = (url: string) => url.replace(/^https?:\/\//, "").split("/")[0];

const fetchFrom = async (
  url: string,
  query: string,
  signal: AbortSignal
): Promise<OverpassResult> => {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded", Accept: "*/*" },
    body: `data=${encodeURIComponent(query)}`,
    signal,
  });

  if (!response.ok) {
    const body = (await response.text())
      .replace(/<[^>]*>/g, " ")
      .replace(/\s+/g, " ")
      .trim()
      .slice(0, 80);
    throw new Error(`HTTP ${response.status}${body ? ` - ${body}` : ""}`);
  }

  return response.json();
};

const runQuery = (query: string): Promise<OverpassResult> =>
  new Promise((resolve, reject) => {
    const controllers: AbortController[] = [];
    const timers: ReturnType<typeof setTimeout>[] = [];
    const failures: string[] = [];
    let settled = false;
    let finished = 0;

    const stopAll = () => {
      timers.forEach(clearTimeout);
      controllers.forEach((c) => c.abort());
    };

    OVERPASS_ENDPOINTS.forEach((url, index) => {
      const controller = new AbortController();
      controllers.push(controller);

      const startTimer = setTimeout(async () => {
        if (settled) return;

        const timeoutTimer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT);
        timers.push(timeoutTimer);

        try {
          const data = await fetchFrom(url, query, controller.signal);
          if (!settled) {
            settled = true;
            stopAll();
            resolve(data);
          }
        } catch (e: any) {
          if (settled) return; // un autre serveur a déjà répondu : on ignore
          const aborted = e?.name === "AbortError" || /cancel|abort/i.test(e?.message ?? "");
          const detail = aborted ? "délai dépassé" : e?.message ?? "erreur inconnue";
          failures.push(`${hostOf(url)} : ${detail}`);
          // Visible dans le terminal Expo pour comprendre quel serveur pose problème.
          console.log(`[Overpass] ${hostOf(url)} -> ${detail}`);
        } finally {
          clearTimeout(timeoutTimer);
          finished++;
          if (!settled && finished === OVERPASS_ENDPOINTS.length) {
            settled = true;
            reject(
              new Error(`Aucun serveur de recherche n'a répondu :\n${failures.join("\n")}`)
            );
          }
        }
      }, index * STAGGER_DELAY);

      timers.push(startTimer);
    });
  });

const categoryOf = (tags: Record<string, string>): CategoryKey | null => {
  const match = CATEGORIES.find((c) => {
    const [tag, value] = c.osm.split("=");
    return tags[tag] === value;
  });
  return match ? match.key : null;
};

const parseElements = (elements: OverpassElement[]): PlaceWithoutDistance[] => {
  const places: PlaceWithoutDistance[] = [];

  for (const el of elements) {
    const latitude = el.lat ?? el.center?.lat;
    const longitude = el.lon ?? el.center?.lon;
    const tags = el.tags ?? {};
    const category = categoryOf(tags);

    if (latitude === undefined || longitude === undefined || !category) continue;

    const label = CATEGORIES.find((c) => c.key === category)?.label ?? "Commerce";

    places.push({
      id: `${el.type}/${el.id}`,
      name: tags.name ?? tags.brand ?? `${label} (sans nom)`,
      category,
      latitude,
      longitude,
    });
  }

  return places;
};

// --- Cache local (pour ne pas solliciter l'API à chaque recherche) -----------

// Clé arrondie à ~1 km : plusieurs recherches dans le même quartier partagent le cache.
const cacheKey = (lat: number, lon: number, categories: CategoryKey[], radius: number) =>
  `places:v1:${lat.toFixed(2)}:${lon.toFixed(2)}:${[...categories].sort().join(",")}:${radius}`;

const readCache = async (key: string): Promise<PlaceWithoutDistance[] | null> => {
  try {
    const raw = await AsyncStorage.getItem(key);
    if (!raw) return null;

    const { savedAt, places } = JSON.parse(raw);
    if (Date.now() - savedAt > CACHE_TTL) return null;

    return places as PlaceWithoutDistance[];
  } catch {
    return null;
  }
};

const writeCache = async (key: string, places: PlaceWithoutDistance[]) => {
  try {
    await AsyncStorage.setItem(key, JSON.stringify({ savedAt: Date.now(), places }));
  } catch {
    // Le cache est facultatif : on ignore les erreurs.
  }
};

// --- Fonction publique -------------------------------------------------------

// Renvoie les commerces des catégories demandées autour d'un point,
// triés du plus proche au plus lointain, limités à MAX_PLACES.
export const searchNearbyPlaces = async (
  latitude: number,
  longitude: number,
  categories: CategoryKey[],
  radius: number = SEARCH_RADIUS
): Promise<Place[]> => {
  if (categories.length === 0) return [];

  const key = cacheKey(latitude, longitude, categories, radius);

  let places = await readCache(key);

  if (!places) {
    const data = await runQuery(buildQuery(latitude, longitude, categories, radius));
    places = parseElements(data.elements ?? []);
    await writeCache(key, places);
  }

  return places
    .filter((p) => categories.includes(p.category))
    .map((p) => ({
      ...p,
      distance: distanceInMeters(latitude, longitude, p.latitude, p.longitude),
    }))
    .sort((a, b) => a.distance - b.distance)
    .slice(0, MAX_PLACES);
};
