import { CategoryKey } from "@/constants/categories";

// Un commerce trouvé via OpenStreetMap.
export interface Place {
  id: string; // ex : "node/123456"
  name: string;
  category: CategoryKey;
  latitude: number;
  longitude: number;
  distance: number; // mètres depuis la position de l'utilisateur
}
