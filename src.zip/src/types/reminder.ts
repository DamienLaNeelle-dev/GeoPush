import { CategoryKey } from "@/constants/categories";

export type ReminderMode = "favorite" | "nearby";
export type ReminderStatus = "active" | "done";

export interface Reminder {
  id: string;
  title: string;
  mode: ReminderMode;

  // Mode "favorite" : le commerce choisi par l'utilisateur (nom + coordonnées).
  placeName: string | null;
  latitude: number | null;
  longitude: number | null;

  // Mode "nearby" : catégories de commerces à rechercher autour de l'utilisateur.
  categories: CategoryKey[];

  radius: number; // rayon de déclenchement, en mètres
  status: ReminderStatus;
  createdAt: number; // Date.now()
  completedAt: number | null;
}

// Ce que le formulaire fournit (le reste est géré par le service).
export type ReminderInput = Pick<
  Reminder,
  "title" | "mode" | "placeName" | "latitude" | "longitude" | "categories" | "radius"
>;
