import { StyleSheet, Text, TouchableOpacity, View } from "react-native";

import { getCategoryLabel } from "@/constants/categories";
import { Place } from "@/types/place";
import { formatDistance } from "@/utils/geo";

interface Props {
  places: Place[];
  onSelect?: (place: Place) => void; // absent = liste en lecture seule (aperçu)
}

export function PlaceList({ places, onSelect }: Props) {
  return (
    <View>
      {places.map((place) => (
        <TouchableOpacity
          key={place.id}
          style={styles.row}
          disabled={!onSelect}
          onPress={() => onSelect?.(place)}
        >
          <View style={{ flex: 1 }}>
            <Text style={styles.name}>{place.name}</Text>
            <Text style={styles.sub}>{getCategoryLabel(place.category)}</Text>
          </View>
          <Text style={styles.distance}>{formatDistance(place.distance)}</Text>
        </TouchableOpacity>
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderWidth: 1,
    borderColor: "#EEEEEE",
    borderRadius: 10,
    marginBottom: 8,
  },
  name: { fontSize: 15, fontWeight: "600" },
  sub: { fontSize: 13, color: "#777777", marginTop: 2 },
  distance: { color: "#5B4BDB", fontWeight: "600", marginLeft: 10 },
});
